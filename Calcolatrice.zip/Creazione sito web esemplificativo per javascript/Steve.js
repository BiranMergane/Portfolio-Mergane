let lampadinaAccesa = false;

function accendiLampadina() {
    const lampadina = document.getElementById('lampadina');
    const bottone = document.getElementById('bottone');
    if (lampadinaAccesa){
    lampadina.src = "Steve in piedi.jpg";
    bottone.textContent = 'Accovaccia Steve';
    lampadinaAccesa = false
    }
    else{
      lampadina.src = "Steve shiftato.png"
      bottone.textContent = 'Alza Steve';
      lampadinaAccesa = true;
    }
  }



  function sommaValore() {
    // Ottenere il riferimento all'elemento di input
    var primoNumero = document.getElementById('primo_numero');
    var secondoNumero = document.getElementById('secondo_numero');
  
    // Ottenere il valore dalla casella di testo
    var primo = parseFloat(primoNumero.value);
    var secondo = parseFloat(secondoNumero.value);
    var somma = primo + secondo;
  
    document.getElementById('somma').value = somma;
  }

  function sottrazioneValore() {
    // Ottenere il riferimento all'elemento di input
    var primoNumero = document.getElementById('primo_numero');
    var secondoNumero = document.getElementById('secondo_numero');
  
    // Ottenere il valore dalla casella di testo
    var primo = parseFloat(primoNumero.value);
    var secondo = parseFloat(secondoNumero.value);
    var somma = primo - secondo;
  
    document.getElementById('sottrazione').value = somma;
  }

  function moltiplicazioneValore() {
    // Ottenere il riferimento all'elemento di input
    var primoNumero = document.getElementById('primo_numero');
    var secondoNumero = document.getElementById('secondo_numero');
  
    // Ottenere il valore dalla casella di testo
    var primo = parseFloat(primoNumero.value);
    var secondo = parseFloat(secondoNumero.value);
    var somma = primo * secondo;
  
    document.getElementById('moltiplicazione').value = somma;
  }

  function divisioneValore() {
    // Ottenere il riferimento all'elemento di input
    var primoNumero = document.getElementById('primo_numero');
    var secondoNumero = document.getElementById('secondo_numero');
  
    // Ottenere il valore dalla casella di testo
    var primo = parseFloat(primoNumero.value);
    var secondo = parseFloat(secondoNumero.value);
    var somma = primo / secondo;
  
    document.getElementById('divisione').value = somma;
  }
