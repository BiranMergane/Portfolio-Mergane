document.addEventListener('DOMContentLoaded', function () {
    // Event listener for "Choose" buttons
    const chooseButtons = document.querySelectorAll('.choose-button');
    chooseButtons.forEach(button => {
        button.addEventListener('click', function () {
            const sectionId = this.dataset.sectionId;
            showSection(sectionId);
        });
    });

    // Event listeners for book operations
    document.getElementById('form-post-book').addEventListener('submit', function (event) {
        event.preventDefault();
        createBook();
    });

    document.getElementById('form-put-book').addEventListener('submit', function (event) {
        event.preventDefault();
        const title = document.getElementById('put-book').value;
        modifyBook(title);
    });

    document.getElementById('btnget-book').addEventListener('click', function () {
        const title = document.getElementById('get-book').value;
        console.log(title)
        getBook(title);
    });

    // Event listeners for bookshelf operations
    document.getElementById('form-post-bookshelf').addEventListener('submit', function (event) {
        event.preventDefault();
        createBookshelf();
    });

    document.getElementById('form-put-bookshelf').addEventListener('submit', function (event) {
        event.preventDefault();
        const id = document.getElementById('put-bookshelf').value;
        modifyBookshelf(id);
    });

    document.getElementById('btnget-bookshelf').addEventListener('click', function () {
        const id = document.getElementById('get-bookshelf').value;
        getBookshelf(id);
    });

    // Event listeners for genre operations
    document.getElementById('form-post-genre').addEventListener('submit', function (event) {
        event.preventDefault();
        createGenre();
    });

    document.getElementById('form-put-genre').addEventListener('submit', function (event) {
        event.preventDefault();
        const id = document.getElementById('put-genre').value;
        modifyGenre(id);
    });

    document.getElementById('btnget-genre').addEventListener('click', function () {
        const id = document.getElementById('get-genre').value;
        getGenre(id);
    });

    // Event listeners for main navigation buttons
    const mainNavButtons = document.querySelectorAll('.main-nav-button');
    mainNavButtons.forEach(button => {
        button.addEventListener('click', function () {
            const sectionId = this.dataset.sectionId;
            showMainSection(sectionId);
        });
    });

    // Initially show the book section
    showMainSection('section-book');
});

function showSection(sectionId) {
    // Hide all subsections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.style.display = 'none';
    });

    // Show the subsection corresponding to the selected button
    const sectionToShow = document.getElementById(sectionId);
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
    }
}

function showMainSection(sectionId) {
    // Hide all main sections
    const mainSections = document.querySelectorAll('.main-section');
    mainSections.forEach(section => {
        section.style.display = 'none';
    });

    // Show the main section corresponding to the selected button
    const sectionToShow = document.getElementById(sectionId);
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
    }

    // Show the GET subsection by default
    const defaultSubsection = sectionToShow.querySelector('.section-get');
    if (defaultSubsection) {
        showSection(defaultSubsection.id);
    }
}

                // Book functions
function getBook(title) {           // Find a book (GET) (funziona)
    fetch(`https://librarymanagementpw.azurewebsites.net/api/Book`)
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        console.log(typeof(data));

        let foundBook = null;

        for (var i = 0; i < data.length; i++) {
            var obj = data[i];
            for (var key in obj) {
                var value = obj[key];
                console.log(key + " = " + value);
                if (key === "title" && obj[key] === title) {
                    foundBook = obj;
                    break;
                }
            }
            if (foundBook) {
                break;
            }
        }

        if (foundBook) {
            let bookDetails = 'Book found:<br>';
            for (let key in foundBook) {
                bookDetails += `${key.charAt(0).toUpperCase() + key.slice(1)}: ${foundBook[key]}<br>`;
            }
            document.getElementById('output-book1').innerHTML = bookDetails;
        } else {
            document.getElementById('output-book1').innerText = 'Book not found';
        }
    })
    .catch(error => {
        document.getElementById('output-book1').innerText = `Error: ${error.message}`;
    });
}

function createBook() {             // Create a book (POST)
    const id = document.getElementById('post-id-book').value;
    const title = document.getElementById('post-title-book').value;
    const price = document.getElementById('post-price-book').value;
    const genreId = document.getElementById('post-genreid-book').value;
    const shelfId = document.getElementById('post-shelfid-book').value;
    const genre = document.getElementById('post-genre-book').value;

    if (!id || !title || !price || !genreId || !shelfId || !genre) {
        document.getElementById('output-book2').innerText = 'Error: All fields are required.';
        return;
    }

    const bookData = { id, title, price, genreId, shelfId, genre };

    fetch('https://librarymanagementpw.azurewebsites.net/api/Book', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('output-book2').innerText = `Book created: ${JSON.stringify(data)}`;
    })
    .catch(error => {
        document.getElementById('output-book2').innerText = `Error: ${error.message}`;
    });
}

function modifyBook(title) {        // Modify a book (PUT)
    // Implement the PUT request to modify a book based on the title
}

                // Bookshelf functions
function getBookshelf(id) {         // Find a bookshelf (GET) (funziona)
    fetch(`https://librarymanagementpw.azurewebsites.net/api/Bookshelf`)
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        console.log(typeof(data));

        let foundBookshelf = null;

        for (var i = 0; i < data.length; i++) {
            var obj = data[i];
            console.log(obj);
            if (obj.id == id) {
                foundBookshelf = obj;
                break;
            }
        }

        if (foundBookshelf) {
            let bookshelfDetails = 'Bookshelf found:<br>';
            for (let key in foundBookshelf) {
                bookshelfDetails += `${key.charAt(0).toUpperCase() + key.slice(1)}: ${foundBookshelf[key]}<br>`;
            }
            document.getElementById('output-bookshelf1').innerHTML = bookshelfDetails;
        } else {
            document.getElementById('output-bookshelf1').innerText = 'Bookshelf not found';
        }
    })
    .catch(error => {
        document.getElementById('output-bookshelf1').innerText = `Error: ${error.message}`;
    });
}

function createBookshelf() {        // Create a bookshelf (POST)
    const id = document.getElementById('post-id-bookshelf').value;
    const code = document.getElementById('post-code-bookshelf').value;

    if (!id || !code) {
        document.getElementById('output-bookshelf2').innerText = 'Error: All fields are required.';
        return;
    }

    const bookshelfData = { id, code };

    fetch('https://librarymanagementpw.azurewebsites.net/api/Bookshelf', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookshelfData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorInfo => {
                throw new Error(`Network response was not ok: ${JSON.stringify(errorInfo)}`);
            });
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('output-bookshelf2').innerText = `Bookshelf created: ${JSON.stringify(data)}`;
    })
    .catch(error => {
        document.getElementById('output-bookshelf2').innerText = `Error: ${error.message}`;
    });
}


function modifyBookshelf(id) {      // Modify a bookshelf (PUT)
    // Implement the PUT request to modify a bookshelf based on the id
}

                // Genre functions
function getGenre(id) {             // Find a genre (GET)
    fetch(`https://librarymanagementpw.azurewebsites.net/api/Genre`)
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        console.log(typeof(data));

        let foundGenre = null;

        for (var i = 0; i < data.length; i++) {
            var obj = data[i];
            console.log(obj); //
            if (obj.id == id) {
                foundGenre = obj;
                break;
            }
        }

        if (foundGenre) {
            let genreDetails = 'Genre found:<br>';
            for (let key in foundGenre) {
                genreDetails += `${key.charAt(0).toUpperCase() + key.slice(1)}: ${foundGenre[key]}<br>`;
            }
            document.getElementById('output-genre1').innerHTML = genreDetails;
        } else {
            document.getElementById('output-genre1').innerText = 'Genre not found';
        }
    })
    .catch(error => {
        document.getElementById('output-genre1').innerText = `Error: ${error.message}`;
    });
}                      

function createGenre() {            // Create a genre (POST)
    const id = document.getElementById('post-id-genre').value;
    const name = document.getElementById('post-name-genre').value;

    const genreData = { id, name };

    fetch('https://librarymanagementpw.azurewebsites.net/api/Genre', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(genreData)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('output-genre2').innerText = `Genre created: ${JSON.stringify(data)}`;
    })
    .catch(error => {
        document.getElementById('output-genre2').innerText = `Error: ${error}`;
    });
}

function modifyGenre(id) {          // Modify a genre (PUT)
    // Implement the PUT request to modify a genre based on the id
}