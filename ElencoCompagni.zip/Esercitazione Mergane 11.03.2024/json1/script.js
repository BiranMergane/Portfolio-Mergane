let text = '{ "compagni" : [' +
'{ "nome":"Alex" , "cognome":"Barbiera" },' +
'{ "nome":"Alex" , "cognome":"Bonura" },' +
'{ "nome":"Marco" , "cognome":"Bottari" },' +
'{ "nome":"Federico" , "cognome":"Cupardo" },' +
'{ "nome":"Omar" , "cognome":"Dambrogi" },' +
'{ "nome":"Federico" , "cognome":"Grassi" },' +
'{ "nome":"Gabriel" , "cognome":"Graziano" },' +
'{ "nome":"Karla" , "cognome":"Herrera" },' +
'{ "nome":"Carlo" , "cognome":"Laguda" },' +
'{ "nome":"Simone" , "cognome":"Marro" },' +
'{ "nome":"Leonardo" , "cognome":"Matta" },' +
'{ "nome":"Tommaso" , "cognome":"Mattioni" },' +
'{ "nome":"Rocco" , "cognome":"Mazza" },' +
'{ "nome":"Biran" , "cognome":"Mergane" },' +
'{ "nome":"Sebastian" , "cognome":"Mihali" },' +
'{ "nome":"Gabriele" , "cognome":"Papagni" },' +
'{ "nome":"Matteo" , "cognome":"Sbarra" },' +
'{ "nome":"Iljas" , "cognome":"Toci" },' +
'{ "nome":"Roberto" , "cognome":"Valendino" },' +
'{ "nome":"Ahmed" , "cognome":"Moustafa" } ]}';

const oggetto = JSON.parse(text);
document.getElementById("numero").innerHTML

function numerocompagno() {
 let x=   document.getElementById("numero").value;
 if (x > 20){
 alert("Inserisci un numero da 0 a 19")
 }else{
 
document.getElementById("demo").innerHTML =
oggetto.compagni[x].nome + " " + oggetto.compagni[x].cognome;
 }

}

